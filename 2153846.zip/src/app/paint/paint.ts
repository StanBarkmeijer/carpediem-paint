export interface Paint {
    _id: string,
    name: string,
    price: number,
    url: string,
    color: string
}